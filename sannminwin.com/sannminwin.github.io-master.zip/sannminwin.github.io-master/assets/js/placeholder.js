
$(document).ready(function(){
	
	$(".form-first-name").val("Name...");
	$(".form-last-name").val("Phone...");
	$(".form-about-yourself").val("Message...");
	
});